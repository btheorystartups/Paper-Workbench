"""Inspect one ZIP attachment without extraction or executing any member.

The archive path is intentionally explicit in the task record. This pilot
only reads the two named manuscript members after inventorying ZIP metadata.
"""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath


PAPER_STEM = "Paper_U_Resolution_Limited_Ultrametric_Concepts_v0.3"


def digest_stream(stream):
    digest = hashlib.sha256()
    while block := stream.read(1024 * 1024):
        digest.update(block)
    return digest.hexdigest()


def main(path_string):
    path = Path(path_string)
    with path.open("rb") as stream:
        archive_hash = digest_stream(stream)
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        unsafe = []
        selected = []
        for entry in entries:
            name = entry.filename.replace("\\", "/")
            parts = PurePosixPath(name).parts
            mode = (entry.external_attr >> 16) & 0xF000
            if (name.startswith("/") or ".." in parts or ":" in parts[0]
                    or mode == 0xA000):
                unsafe.append(name)
            if name.endswith((PAPER_STEM + ".tex", PAPER_STEM + ".pdf")):
                with archive.open(entry) as stream:
                    selected.append({"member": name, "bytes": entry.file_size,
                                     "sha256": digest_stream(stream)})
        result = {
            "archive": str(path), "archive_sha256": archive_hash,
            "member_count": len(entries),
            "compressed_bytes": sum(e.compress_size for e in entries),
            "uncompressed_bytes": sum(e.file_size for e in entries),
            "unsafe_member_paths_or_links": unsafe,
            "selected_manuscript_members": selected,
            "extracted": False,
        }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: inspect_attachment.py PATH_TO_ZIP")
    main(sys.argv[1])
