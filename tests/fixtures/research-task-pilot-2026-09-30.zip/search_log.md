# Targeted literature and source-search ledger

Search date: 2026-09-30, Asia/Bangkok. This is a **targeted exploratory search**,
not a systematic review or proof of absence of prior art.

| Search / source | Inspected result | Bearing on the question | Limit |
|---|---|---|---|
| Local Paper U current v0.3, Theorem 2.2 and Example 2.3 | TeX lines 76-121; PDF pp. 2-3 visually inspected | Finite ball quotient metric, discrete cell quotient, failure of arbitrary fixed-metric partition collapse | Other Paper U results not audited |
| Original Paper U fresh-referee ZIP | 39-member central directory inspected; selected revised TeX/PDF hashed in-place | Demonstrates ZIP input handling without extraction; selected member hashes exactly match current TeX/PDF | Other archive members were not opened or executed |
| Local ProLT core v0.8.1 | TeX lines 272-298, 365-387, 531-547 | Positive-observation signatures, upper-set topology, Sierpinski counterexample | Full manuscript not reread |
| Local Successive Concept Differentiation v0.5 | Definition 6.1 and Section 7; PDF pp. 8-9 visually inspected | One-bit carrier splitting `R subset Q x {0,1}` and forgetful map | Homology/descent results not audited |
| Local CM/LM Boolean Operator Calculus | TeX lines 650-680, 699-711 | Truth tensor and formula-valued LM lift; its type is an encoding of a Boolean function | Full operator calculus not audited |
| `generalized ultrametric spaces preorder Alexandroff topology` and `quasi-ultrametric finite poset Alexandroff topology` | Bonsangue, van Breugel & Rutten, *Generalized ultrametric spaces: completion, topology, and powerdomains via the Yoneda embedding* (CWI report, 1995), https://ir.cwi.nl/pub/4940 | Direct conceptual predecessor unifying preorders and ordinary ultrametrics, with corresponding Alexandroff and ball topologies | Institutional abstract inspected; linked PDF fetch returned a cache error |
| `quasi-ultrametric finite spaces directed graphs` | Gurvich & Vyalyi, *Characterizing (quasi-)ultrametric finite spaces in terms of (directed) graphs*, *Discrete Applied Mathematics* 160 (2012), 1742-1756, https://doi.org/10.1016/j.dam.2012.03.034 | Nested transitive digraph representation of finite quasi-ultrametrics; its stated positive off-diagonal convention differs from the directed zero relation used here | Publisher abstract and accessible introduction only |
| `finite topological spaces T1 discrete Stong` | Stong, *Finite topological spaces*, *Trans. AMS* 123 (1966), 325-340, https://doi.org/10.1090/S0002-9947-1966-0195042-2 | Classical finite-space background; the T1/discrete step is also proved directly in ProLT | Bibliographic record located; full paper not needed for this proof |
| `quasi ultrametric extension fibers preorder ultrametric quotient amalgamation` | Found Bonsangue et al. again and adjacent quasi-pseudometric literature | No exact predecessor for formula (2) established by this limited search | Search failure does not establish novelty |

Excluded search results: Wikipedia, forum posts, tertiary summaries, and
papers whose object was a metric tree rather than a generalized ultrametric
on observable states. The pilot used the primary institutional/publisher
records above for external claims. It did not search every database,
language, citation network, or historical terminology.
