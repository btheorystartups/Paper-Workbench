# Delegated research task pilot

Date: 2026-09-30 (Asia/Bangkok)

**Outcome:** A finite ultrametric hierarchy and a ProLT positive-observation
refinement can be combined by a directed generalized ultrametric under the
stated ball-partition assumptions. An ordinary symmetric ultrametric cannot
have the refined ProLT topology when the new observation splits a state.
This is a verified elementary construction and boundary, **not a novelty or
publication claim**.

Read in this order:

1. `task_contract.md` - exact question, inputs, limits, and return states.
2. `research_report.md` - definitions, proof, minimal example, relevance,
   literature assessment, and unresolved issues.
3. `search_log.md` - searches and primary sources inspected.
4. `verification.py` and `verification_results.json` - bounded finite checks;
   the proof in the report supplies the general argument.
5. `attachment_zip_inspection.json` and `inspect_attachment.py` - an actual
   Paper U ZIP was inventoried without extraction; its selected manuscript
   members matched the current files byte for byte.
6. `source_manifest.json` - source paths, hashes, and exact locators.
7. `package_manifest.json` - hashes of the files in this package.

The original papers are not duplicated here. Their exact locations and SHA-256
hashes are in `source_manifest.json`. No manuscript was requested as an output,
so this pilot returns a research report rather than an unreviewed draft paper.

**Status:** completed within the selected scope. No task-wide token, time, or
credit cap was supplied; no cap was reached. This package records what was
checked and what remains unchecked.
