"""Bounded finite checks for the directed hierarchy lift; stdlib only.

The checks do not replace the general proof in research_report.md.
Run: python verification.py > verification_results.json
"""

from __future__ import annotations

import itertools
import json


def is_ultrametric(points, distance):
    return all(
        distance(x, z) <= max(distance(x, y), distance(y, z))
        for x, y, z in itertools.product(points, repeat=3)
    )


def all_coarse_ultrametrics(n):
    pairs = list(itertools.combinations(range(n), 2))
    for values in itertools.product((1, 2, 3), repeat=len(pairs)):
        matrix = {(i, i): 0 for i in range(n)}
        for (i, j), value in zip(pairs, values):
            matrix[i, j] = matrix[j, i] = value
        if is_ultrametric(range(n), lambda i, j: matrix[i, j]):
            yield matrix


def check_instance(n, coarse, fibers):
    states = tuple((cell, bit) for cell in range(n) for bit in fibers[cell])
    positive_distances = [coarse[i, j] for i in range(n) for j in range(i + 1, n)]
    epsilon = min(positive_distances) / 2 if positive_distances else 0.5

    def distance(x, y):
        if x[0] != y[0]:
            return coarse[x[0], y[0]]
        return 0 if x[1] <= y[1] else epsilon

    def order(x, y):
        return x[0] == y[0] and x[1] <= y[1]

    assert is_ultrametric(states, distance)
    assert all((distance(x, y) == distance(y, x) == 0) == (x == y)
               for x, y in itertools.product(states, repeat=2))
    assert all(distance(x, y) == coarse[x[0], y[0]]
               for x, y in itertools.product(states, repeat=2) if x[0] != y[0])

    # Every forward ball, at every distinct threshold boundary, is an upper set.
    values = sorted({distance(x, y) for x, y in itertools.product(states, repeat=2)})
    radii = [values[0] + 0.01]
    radii.extend((a + b) / 2 for a, b in zip(values, values[1:]))
    radii.append(values[-1] + 1)
    for x in states:
        principal = {y for y in states if order(x, y)}
        assert {y for y in states if distance(x, y) < epsilon / 2} == principal
        for radius in radii:
            ball = {y for y in states if distance(x, y) < radius}
            assert all(z in ball for y in ball for z in states if order(y, z))

    def symmetrized(x, y):
        return max(distance(x, y), distance(y, x))

    assert is_ultrametric(states, symmetrized)
    assert all((symmetrized(x, y) == 0) == (x == y)
               for x, y in itertools.product(states, repeat=2))
    return len(states)


def main():
    counts = {}
    total = 0
    max_states = 0
    for n in range(1, 4):
        count = 0
        coarse_count = 0
        for coarse in all_coarse_ultrametrics(n):
            coarse_count += 1
            for fibers in itertools.product(((0,), (1,), (0, 1)), repeat=n):
                max_states = max(max_states, check_instance(n, coarse, fibers))
                count += 1
        counts[str(n)] = {"coarse_ultrametrics": coarse_count,
                          "fiber_profiles_checked": count}
        total += count
    print(json.dumps({"status": "passed", "instances_checked": total,
                      "maximum_refined_states": max_states,
                      "by_coarse_cell_count": counts}, indent=2))


if __name__ == "__main__":
    main()
