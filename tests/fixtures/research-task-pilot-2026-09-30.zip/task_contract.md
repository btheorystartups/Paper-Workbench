# Pilot task contract and proposed workbench behavior

## Executed research question

Let a finite latent ultrametric space be observed through a finite partition
into nonempty balls. Paper U gives an ultrametric `delta` on the set `C` of
partition cells. Include the cell indicators among the old positive Boolean
observations, so distinct cells have incomparable ProLT signatures. Add one
Boolean observation `psi`, represented if desired by its CM truth tensor and
formula-valued LM lift. Let `R` be the realized refined signatures, with the
ProLT upper-set topology, and let `pi:R -> C` forget the new bit.

**Question:** Can the exact inter-cell distances `delta` be retained on `R`
while the induced distance topology equals the ProLT positive-observation
topology? What changes if the distance must be an ordinary symmetric
ultrametric versus an asymmetric generalized ultrametric?

Deliver a proof or counterexample, nearest relevant prior art, a finite check,
and a bounded status report. Do not treat LM/CM representation as a metric or
claim originality from a failed search.

## Inputs and scope

- Paper U v0.3, original fresh-referee source and PDF: finite ball quotient,
  Theorem 2.2 and Example 2.3.
- ProLT core v0.8.1: observation signatures, upper-set topology, Sierpinski
  example.
- Successive Concept Differentiation v0.5: Definition 6.1 and Section 7
  carrier-splitting signature model.
- CM/LM Boolean Operator Calculus: Section on logical tensor and LM lift.
- Primary-source literature search on generalized ultrametrics, finite
  quasi-ultrametrics, and finite topology.
- The original fresh-referee Paper U ZIP was inspected without extraction:
  39 members, no unsafe paths or links detected, and the selected TeX/PDF
  members matched the current files by SHA-256. See
  `attachment_zip_inspection.json`.

This task does not audit the full four manuscripts, certify their other
theorems, establish cognitive or physical applications, or prepare a paper.

## Proposed task-runner contract for Paper-Workbench

An attachment may be a PDF, TeX, Markdown file, or ZIP. The runner should
record its hash and source, enumerate a ZIP before extraction, enforce size
and expansion limits, reject traversal and link escapes, and never execute
attached code automatically. It should identify which version is current from
the package's own manifest or ask when that cannot be established.

The user may select a **task-wide token budget**, wall-clock deadline, and
spending/credit ceiling independently. Tokens are useful when the provider
reports them reliably; they are distinct from a single call's context or
output-token limit. If exact account usage is unavailable, the interface
must label the token total an estimate and not imply control of plan quota.
Defaults should be conservative but configurable.

The runner should checkpoint findings, citations, and intermediate artifacts
as it goes, and reserve capacity for packaging. At a soft limit it stops new
research, synthesizes the checkpoints, and returns a ZIP marked
`limit_reached_partial`. At a hard interruption, the coordinator packages
the last saved checkpoints. "Return everything" means **everything gathered
before the cutoff**; it cannot promise work after a hard time or token cap.
The report must distinguish `proved`, `counterexample`, `prior_art_found`,
`unresolved`, `limit_reached_partial`, and `failed`.

The default ZIP template should include: task definition, main findings,
proof/counterexample attempts, source and search ledger, verification
artifacts, open questions, and a hash manifest. A requested manuscript,
reviewer report, or other deliverable is included under `deliverables/` only
when the user specifies it or chooses an appropriate template. The
coordinating agent reviews evidence before integrating any result into a
paper or accepting a research-object status.

## Pilot result state

`proved_with_prior_art_boundary`: the construction and obstruction are proved
for the precise finite model. The broad idea of generalized ultrametrics
combining preorders and ultrametrics is already in prior literature. The
specific formula was not subject to an exhaustive priority search.
